<?php

session_start();
//$_SESSION['Admin'];
$db_name ="id10518757_tracking";
$mysql_username = "id10518757_teamproject28";
$mysql_password = "Team.2019";
$server_name = "localhost";
$try="this is try";

// connect to database
$db = mysqli_connect($server_name,$mysql_username,$mysql_password,$db_name);

if (isset($_POST['addP'])) {
	registerP();
}
if (isset($_POST['send'])) {
	send1();
}
if (isset($_POST['updatec'])) {
	updatec();
}
if (isset($_POST['updatep'])) {
	updatep();
}
if (isset($_POST['updated'])) {
	updated();
}
if (isset($_POST['updateb'])) {
	updateb();
}
if (isset($_POST['logout'])) {
	logout();
}
if (isset($_POST['addC'])) {
	registerC();
}
if (isset($_POST['AddDriver'])) {
	registerDriver();
}
if (isset($_POST['AddBus'])) {
	registerBus();
}
if (isset($_POST['AddAdmin'])) {
	registerAdmin();
}
if (isset($_POST['save'])) {
	updatea();
}
if (isset($_POST['reset'])) {
	resetpass();
}
if(isset($_POST['delete']))
{deleteu();}
function send1(){
     global $db, $errors; 
$rid=$_POST['id'];
$aid=$_POST['aid'];
$type=$_POST['type'];
$content=$_POST['content'];
$time= date('Y-m-d H:i:s');
if($type=="Parent"){
$sql1 = "INSERT INTO `Message` (`MID`, `MContent`, `MDate`, `PID`, `AID`,`DID`) VALUES (NULL,'$content','$time', '$rid','$aid',NULL)";
	if(mysqli_query($db, $sql1)){
	  $last_id = mysqli_insert_id($db);echo "<script>
    alert('Message Sent successfully');
</script>";
	  }else{echo "failed". mysqli_error($db);}}
	  
	  else{$sql1 = "INSERT INTO `Message` (`MID`, `MContent`, `MDate`, `PID`, `AID`,`DID`) VALUES (NULL,'$content',time(),NULL,'$aid','$rid')";
	if(mysqli_query($db, $sql1)){
	  $last_id = mysqli_insert_id($db);echo "<script>
    alert('Message Sent successfully');
</script>";
	  }else{echo "failed". mysqli_error($db);}};
}
function  resetpass(){
     global $db, $errors; 
	$id  = $_POST['AID'];
		$query = "SELECT * FROM `Admin` WHERE AID='$id'";
		$results = mysqli_query($db, $query);
		$count = mysqli_num_rows($results);
            if ($count == 1) {
$pass1  = $_POST['APassword'];
$pass2  = $_POST['APassword1'];
if($pass1 != $pass2){echo "<script>
    alert('Passwords Doesnt Match');
</script>";
	}
else{$sql1="UPDATE Admin SET `APassword` = '$pass1' WHERE `AID` = $id ";
if(mysqli_query($db, $sql1)){
	echo "<script> 
    alert('updated Password Successfully);
</script>";
 }
  else {echo  mysqli_error($db); echo "<script>
    alert('Couldn't update Reset Password');
</script>";
 }}
    }else{echo "<script> 
    alert('Wrong ID Nmuber');
</script>";
 }


}
if(isset($_POST['deletea'])){deletea();}
function deletea(){
{ global $db, $errors; 
$id=$_POST['id'];
$sql2 = "DELETE FROM Admin WHERE AID = $id";
if(mysqli_query($db, $sql2)){echo "
<script>alert('Admin Deleted');</script> ";
}else{echo "failed". mysqli_error($db);  }}    
}
function deleteu()
{
 global $db, $errors; 
$type=$_POST['type1'];
$id=$_POST['id1'];
if($type=="Child"){
$sql1="DELETE FROM Parent_Child WHERE CID = $id";
if(mysqli_query($db, $sql1)){
$sql2 ="DELETE FROM $type WHERE CID = $id";
if(mysqli_query($db, $sql2)){
echo "<script>alert('Child Deleted');</script>";

}else{echo 'failed'. mysqli_error($db);  }}}

elseif($type=="Parent"){
$sql1="DELETE FROM Parent_Child WHERE PID = $id";
if(mysqli_query($db, $sql1)){
$sql2 ="DELETE FROM $type WHERE PID = $id";
if(mysqli_query($db, $sql2)){
echo "<script>alert('Parent Deleted');</script>";

}else{echo "failed". mysqli_error($db);  }}}

elseif($type=="Driver"){
$sql1="DELETE FROM Driver_Trips WHERE DID = $id";
if(mysqli_query($db, $sql1)){
$sql2="DELETE FROM Driver WHERE DID = $id";    
 if(mysqli_query($db, $sql2)){
echo "<script>alert('Driver Deleted');</script>";

}else{echo "failed". mysqli_error($db);  } }
}
elseif($type=="Bus"){
 $sql1="DELETE FROM Bus_Trips WHERE BID = $id";
if(mysqli_query($db, $sql1)){
 $sql2="DELETE FROM Bus WHERE BID = $id";
 if(mysqli_query($db, $sql2)){
echo "<script>alert('Bus Deleted');</script>";
 }else{echo 'failed'. mysqli_error($db);   }
}
    
}
    
}
 

function updatea(){
    global $db, $errors; 
	$id  = $_POST['id'];
	$FName  = $_POST['AName'];
    $Gender  = $_POST['AGender'];
	$Phone  = $_POST['APhone'];
	$Password= $_POST['APassword'];

$sql="UPDATE Admin SET `AName` = '$FName', `APhone` = '$Phone', `AGender` = '$Gender',`APassword` = '$Password' WHERE `AID` = $id ";
if(mysqli_query($db, $sql)){
echo "<script>alert('updated info. successfully');</script>";
 	 }
  else {echo  mysqli_error($db);echo "<script>
    alert('Couldn't update info.');
</script>";
	}
}
    

function updatec()
{ global $db, $errors; 
	$id  = $_POST['id'];
	$FName  = $_POST['FName'];
	$LName  = $_POST['LName'];
	$Status= $_POST['Status'];
	$lng= $_POST['lng'];
	$lat= $_POST['lat'];
	$Gender  = $_POST['Gender'];
$sql="UPDATE Child SET `CFName` = '$FName', `CLName` = '$LName', `CGender` = '$Gender', `CStatus` = '$Status',`Longitude` = '$lng', `Latitude` = '$lat' WHERE `CID` = $id";
if (mysqli_query($db, $sql)) {
echo"<script>
    alert('updated info. successfully');
</script>";
}
  else { echo "<script>
    alert('Couldn't update info.');
</script>";
	}
}
function updatep(){
global $db, $errors; 
	$id  = $_POST['id'];
	$FName  = $_POST['FName'];
	$LName  = $_POST['LName'];
	$Gender  = $_POST['Gender'];
	$Phone  = $_POST['Phone'];
$sql="UPDATE Parent SET `PFName` = '$FName', `PLName` = '$LName', `PGender` = '$Gender',`PPhone` = '$Phone'  WHERE `PID` = $id";
if (mysqli_query($db, $sql)) { 
	 echo"<script>
    alert('updated info. successfully');
</script>";
	 }
  else {echo "<script>
    alert('Couldn't update info.');
</script>";
	}
}
function updated(){
global $db, $errors; 
	$id  = $_POST['id'];
	$FName  = $_POST['FName'];
	$LName  = $_POST['LName'];
	$Gender  = $_POST['Gender'];
	$Phone  = $_POST['Phone'];
	$Status= $_POST['Status'];

$sql="UPDATE Driver SET `DFName` = '$FName', `DLName` = '$LName', `DGender` = '$Gender',`DPhone` = '$Phone', `DStatus` = '$Status' WHERE `DID` = $id";
if (mysqli_query($db, $sql)) { 
	echo "<script>
    alert('updated info. successfully');
</script>";}
  else {echo "<script>
    alert('Couldn't update info.');
</script>";
	}
}
function updateb(){
global $db, $errors; 
	$id  = $_POST['id'];
	$Model  = $_POST['BM'];
	$Capacity  = $_POST['BC'];
	$Number  = $_POST['BNO'];

$sql="UPDATE Bus SET `BModel` = '$Model', `BCapacity` = '$Capacity', `BNO` = '$Number' WHERE `BID` = $id";
if (mysqli_query($db, $sql)) {
	echo "<script>
    alert('updated info. successfully');
</script>";
 }
  else { echo "<script>
    alert('Couldn't update info.');
</script>";
	}
}
function registerAdmin(){
   
   global $db, $errors; 
  
  
	$AName    = $_POST['AName'];
	$APhone  =  $_POST['APhone'];
	$AGender  = $_POST['AGender'];
    
	$APassword=randomPassword();

$sql1 = "INSERT INTO `Admin` (`AID`, `AName`, `APhone`, `AGender`, `APassword`) VALUES (NULL,'$AName','$APhone', '$AGender','$APassword')";
	if(mysqli_query($db, $sql1)){
	  $last_id = mysqli_insert_id($db);echo "<script>
    alert('Admin added successfully with id: ".json_encode($last_id)."and with password: '".$APassword."');
</script>";
	  }
}
function registerDriver(){
   global $db, $errors; 
  
   $AdminID=$_SESSION['Admin']['AID'];
	$DFName    = $_POST['DFName'];
	$DLName    = $_POST['DLName'];
	$DPhone  =  $_POST['DPhone'];
	$DGender  = $_POST['DGender'];
	$DStatus=$_POST['DStatus'];
   	$DPassword=randomPassword();

$sql1 = "INSERT INTO `Driver` (`DID`, `DPassword`, `DFName`, `DLName`, `DPhone`, `DGender`, `DStatus`, `AID`) VALUES (NULL, '$DPassword', '$DFName', '$DLName', '$DPhone', '$DGender', '$DStatus', '$AdminID')";
if (mysqli_query($db, $sql1)) {$did = $db->insert_id;
    echo "<script>
    alert('Driver added successfully with id: ".json_encode($did)." and with password: '".$DPassword."');
</script>";
 }
  else {echo "Error inserting record: " . mysqli_error($db);} }
function registerBus(){
     global $db, $errors; 
  
   $AdminID=$_SESSION['Admin']['AID'];
	$BNO    = $_POST['BNO'];
	$BModel  =  $_POST['BModel'];
	$BCapacity  = $_POST['BCapacity'];
   
$sql1 = "INSERT INTO `Bus` (`BID`, `BNO`, `BCapacity`, `BModel`, `AID`) VALUES (NULL, '$BNO', '$BCapacity', '$BModel', '$AdminID')";
	if (mysqli_query($db, $sql1)) { $bid = $db->insert_id;echo "<script>
    alert('Bus  added successfully with id: ".json_encode($bid).");
</script>";
}

    else {echo "Error updating record: " . mysqli_error($db);}
}
function registerC(){
	// call these variables with the global keyword to make them available in function
	global $db, $errors, $username, $email;

	// receive all input values from the form. Call the e() function
    // defined below to escape form values
    $AdminID=$_SESSION['Admin']['AID'];
	$CFName    = $_POST['CFName'];
	$CLName    = $_POST['CLName'];
	$CGender  =  $_POST['CGender'];
	$CStatus  = $_POST['CStatus'];
	$CAddres  =  "IRBID";
	$pid  = $_POST['pid'];
	$lng= $_POST['lng'];
	
	$lat1= $_POST['lat'];
	
        $lng=(double)$lng;
	    $lat1=(double)$lat1;
	   $cid;    
$query = "SELECT * FROM `Parent` WHERE PID='$pid'";
		$results = mysqli_query($db, $query);
		$count = mysqli_num_rows($results);
            if ($count == 1) {
$sql = "INSERT INTO `Child` (`CID`, `CFName`, `CLName`, `CGender`, `CStatus`, `CAddres`, `Longitude`, `Latitude`, `AID`) VALUES (NULL, '$CFName','$CLName', '$CGender', '$CStatus', '$CAddres','$lng','$lat1','$AdminID')";
	  if(mysqli_query($db, $sql))
	{
	    $cid = $db->insert_id;"<script>
    alert('Bus  added successfully with id: ".json_encode($cid).");
</script>"; }
	else {echo "failed". mysqli_error($db);}
	
$sql1 = "INSERT INTO `Parent_Child` (`PID`, `CID`) VALUES ('$pid', '$cid')";
if(mysqli_query($db, $sql1))
	{echo "<script>
    alert('Child added successfully with id: ".json_encode($cid)."');
</script>";
	}
	else {echo "failed". mysqli_error($db);} }else{echo "<script>
    alert('Parent Id not found');</script>";}}
function randomPassword() {
    $alphabet = '1234567890abcdefghijklmnopqrstuvwxyz1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $pass = array(); //remember to declare $pass as an array
    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
    for ($i = 0; $i < 8; $i++) {
        $n = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    return implode($pass); //turn the array into a string
}
if (isset($_POST['login_btn'])) {
	login();
}
function registerP(){
       global $db, $errors; 

$AdminID=$_SESSION['Admin']['AID'];
$PFName= $_POST['PFName'];
$PLName= $_POST['PLName'];
$PPhone= $_POST['PPhone'];
$PGender= $_POST['PGender'];
$cid = isset($_POST['cid']) ? $_POST['cid'] : 0;
echo $cid;
$PPassword=randomPassword();

if($cid ==0000){
$sql1 = "INSERT INTO `Parent` (`PID`,`PFName`,`PLName`, `PPassword`, `PPhone`, `PGender`, `AID`) 
	   	VALUES (NULL, '$PFName','$PLName', '$PPassword', '$PPhone', '$PGender','$AdminID')";
	if(mysqli_query($db, $sql1))
	{$pid = $db->insert_id;echo "<script>
    alert('Parent added successfully with id: ".json_encode($pid)." and with Password: '".$PPassword."');
</script>";
}
	else {echo "failed". mysqli_error($db);};    
}
else{
$query = "SELECT * FROM `Child` WHERE CID='$cid'";
		$results = mysqli_query($db, $query);
		$count = mysqli_num_rows($results);
            if ($count == 1) {
$sql = "INSERT INTO `Parent` (`PID`,`PFName`,`PLName`, `PPassword`, `PPhone`, `PGender`, `AID`) 
	   	VALUES (NULL, '$PFName','$PLName', '$PPassword', '$PPhone', '$PGender','$AdminID')";
if(mysqli_query($db, $sql)) {$pid = $db->insert_id;
}
	else {echo "failed". mysqli_error($db);};
	
$sql1 = "INSERT INTO `Parent_Child` (`PID`, `CID`) VALUES ('$pid', '$cid')";
if(mysqli_query($db, $sql1))
	{ echo "<script>
    alert('Parent added successfully with id: ".json_encode($pid)." and with Password: '".$PPassword."');
</script>";
	   	}
	else {echo "failed". mysqli_error($db);} }else{echo "<script>
    alert('Child does not exist');
</script>";}
}



}

// LOGIN USER
function login(){
	global $db, $ID, $errors;

	$ID =$_POST['AID'];
	$password = $_POST['APassword'];
	$query = "SELECT * FROM `Admin` WHERE AID='$ID' and APassword='$password'";
		$results = mysqli_query($db, $query);
		$count = mysqli_num_rows($results);

            if ($count == 1) { // user found
            
			$logged_in_user = mysqli_fetch_assoc($results);
				$_SESSION['Admin'] = $logged_in_user;
				$_SESSION['success']  = "You are now logged in";
                header('location: Dashboard.php');		  
			}else {echo " 
			<script> alert('wrong ID or Passwrord')
			</script>";}


	//}
}

function getUserById($id){
	global $db;
	$query = "SELECT * FROM Admin WHERE AID=" . $id;
	$result = mysqli_query($db, $query);

	$user = mysqli_fetch_assoc($result);
	return $user;
}

// escape string
function e($val){
	global $db;
	return mysqli_real_escape_string($db, trim($val));
}

function logout(){
 session_destroy();  
 header('location:index.php');  
}

?>