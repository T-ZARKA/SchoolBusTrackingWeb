<?php
$db_name ="id10518757_tracking";
$mysql_username = "id10518757_teamproject28";
$mysql_password = "Team.2019";
$server_name = "localhost";
$conn = mysqli_connect($server_name,$mysql_username,$mysql_password,$db_name);
/*if($conn){
	echo "Connection Success";
}
else {
echo "Failed To Connection";
}*/
?>
