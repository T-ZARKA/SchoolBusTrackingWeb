<?php 
	include('functions.php');
$expireAfter = 15;
 
//Check to see if our 'last action' session
//variable has been set.
if(isset($_SESSION['last_action'])){
    
    //Figure out how many seconds have passed
    //since the user was last active.
    $secondsInactive = time() - $_SESSION['last_action'];
    
    //Convert our minutes into seconds.
    $expireAfterSeconds = $expireAfter * 60;
    
    //Check to see if they have been inactive for too long.
    if($secondsInactive >= $expireAfterSeconds){
        //User has been inactive for too long.
        //Kill their session.
        session_unset();
        session_destroy();
header('location: index.php');		  

        
    }
    
}
 
//Assign the current timestamp as the user's
//latest activity
$_SESSION['last_action'] = time();
echo "<!DOCTYPE html>

<html lang='en'>

<head>
  <!-- Required meta tags -->
  <meta charset='utf-8'>
  <meta name='viewport' content='width=device-width, initial-scale=1, shrink-to-fit=no'>
  <title>Admin Dashboard</title>
  <!-- plugins:css -->
  <link rel='stylesheet' href='AdminPagesStyle/vendors/iconfonts/mdi/css/materialdesignicons.min.css'>
  <link rel='stylesheet' href='AdminPagesStyle/vendors/css/vendor.bundle.base.css'>
  <!-- endinject -->
  <!-- inject:css -->
  <link rel='stylesheet' href='AdminPagesStyle/css/style.css'>
  <!-- endinject -->
  <link rel='shortcut icon' href='AdminPagesStyle/images/favicon.png' />
  <script src='https://api.tiles.mapbox.com/mapbox-gl-js/v1.3.1/mapbox-gl.js'></script>
    <link href='https://api.tiles.mapbox.com/mapbox-gl-js/v1.3.1/mapbox-gl.css' rel='stylesheet' />
     <script src='https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-geocoder/v4.4.1/mapbox-gl-geocoder.min.js'></script>
<link rel='stylesheet' href='https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-geocoder/v4.4.1/mapbox-gl-geocoder.css' type='text/css' />
    <style>
        .mapouter{position:relative;text-align:right;height:100%;width:100%;} #map {overflow:hidden;background:none!important;height:600px;width:900px;}</style>
</head>
<body>
    <style type='text/css'>
#info {
display: block;
position: relative;
margin: 0px auto;
width: 50%;
padding: 10px;
border: none;
border-radius: 3px;
font-size: 12px;
text-align: center;
color: #222;
background: #fff;
}
</style>
  <div class='container-scroller'>
    <!-- partial:partials/_navbar.html -->
    <nav class='navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row'>
      <div class='text-center navbar-brand-wrapper d-flex align-items-center justify-content-center'>
        <a class='navbar-brand brand-logo' href='index.php'><img src='AdminPagesStyle/images/bus1.png' alt='logo'/></a>
<a class='navbar-brand brand-logo-mini' href='index.php'><img src='AdminPagesStyle/images/bus1.png' alt='logo'/></a>";

        if (isset($_SESSION['success'])) :
echo" <div class='error success'>
			
			</div>";
		 endif ;
     echo "</div>
        <div class='navbar-menu-wrapper d-flex align-items-stretch'>
                    <ul class='navbar-nav navbar-nav-right'>
 
          <li class='nav-item dropdown'>
            <a class='nav-link' href='Messages.php' >
              <i class='mdi mdi-email-outline'></i>
              <span class='count-symbol bg-warning'></span>
            </a></li>
           <li class='nav-item nav-logout d-none d-lg-block'>
            <a class='nav-link' href='index.php'>
              <i class='mdi mdi-power'></i>
            </a>
          </li>
           <li class='nav-item dropdown'>
            <a class='nav-link' href='profile.php' >
              <i class='mdi mdi-face menu-icon'></i>
              <span class='count-symbol bg-warning'></span>
            </a></li>
                    </ul>
                    <button class='navbar-toggler navbar-toggler-right d-lg-none align-self-center' type='button' data-toggle='offcanvas'>
                        <span class='mdi mdi-menu'></span>
                    </button>
                </div>
    </nav>
    <!-- partial -->
    <div class='container-fluid page-body-wrapper'>
      <!-- partial:partials/_sidebar.html -->
      <nav class='sidebar sidebar-offcanvas' id='sidebar'>
        <ul class='nav'>
          <li class='nav-item nav-profile'>
            <a href='#' class='nav-link'>
              
              <div class='nav-profile-text d-flex flex-column'>
                <span class='font-weight-bold mb-2'>";
                    if (isset($_SESSION['Admin'])) : 
					echo "<strong>Welcome  ".  $_SESSION['Admin']['AName']. "</strong>";

				 endif;
         echo"      </span>
              </div>
            </a>
          </li>
          <li class='nav-item'>
            <a class='nav-link' href='Dashboard.php'>
              <span class='menu-title'>Dashboard</span>
              <i class='mdi mdi-home menu-icon'></i>
            </a>
          </li>
         <li class='nav-item'>
            <a class='nav-link' href='AddParent.php'>
              <span class='menu-title'>
                
                  Add Parent</span>
              <i class='mdi mdi-contacts menu-icon'></i>
            </a>
          </li>
          <li class='nav-item'>
            <a class='nav-link' href='AddStudent.php'>
              <span class='menu-title'>
                
                  Add Student</span>
              <i class='mdi mdi-human-child menu-icon'></i>
            </a>
          </li>
          
          <li class='nav-item'>
            <a class='nav-link' href='AddAdmin.php'>
              <span class='menu-title'>Add Admin  </span>
              <i class='mdi mdi-account-star menu-icon'></i>
            </a>
          </li>
          <li class='nav-item'>
            <a class='nav-link' href='AddDriverBus.php'>
              <span class='menu-title'>Add Driver/Bus </span>
              <i class='mdi mdi-bus menu-icon'></i>
            </a>
          </li>
         <li class='nav-item'>
            <a class='nav-link' href='ShowInfo.php'>
              <span class='menu-title'>Search</span>
              <i class='mdi mdi-account-search menu-icon'></i>
            </a>
          </li>
          
        </ul>
      </nav>
      <!-- partial -->
      <div class='main-panel'>
        <div class='content-wrapper'>
         
          <div class='page-header'>
            <h3 class='page-title'>
              <span class='page-title-icon bg-gradient-primary text-white mr-2'>
                <i class='mdi mdi-home'></i>                 
              </span>
              Messages
            </h3>
            </div>
               <div class='main-panel'>
              <div class='col-12 grid-margin'>
              <div class='card'>
                                  <div class='card-body'>
                                  <form method='POST' action='Messaging.php'>

                                                    <table class='table table-striped'>
                                   <thead>
                      <tr>
                        <th>User ID</th>
                       <th>User Type</th><th>Name</th>
                        <th>Content</th>
                        <th>Date</th>
                      </tr>
                    </thead>
                    <tbody>";
$db_name ='id10518757_tracking';
$mysql_username = 'id10518757_teamproject28';
$mysql_password = 'Team.2019';
$server_name = 'localhost';
// connect to database
$db = mysqli_connect($server_name,$mysql_username,$mysql_password,$db_name);
$count=0;

// Check connection
if ($db->connect_error) {
die('Connection failed: ' . $db->connect_error);
}
$id=$_SESSION['Admin']['AID'];
$sql ="SELECT * FROM Message WHERE AID=$id";
if($s = mysqli_query($db, $sql)){

echo "<tr>";
$rows = mysqli_num_rows($s); 
 if ($rows) {
 while ($row = mysqli_fetch_array($s)) {
if($row['DID']!=NULL){
$id1=$row['DID'];$sql1="SELECT * FROM Driver WHERE DID=$id1";$s2 = mysqli_query($db, $sql1);$row2 = mysqli_fetch_array($s2);$name=$row2['DFName']." ".$row2['DLName'];
echo  "<td>".$row['DID']."</td><td>Driver</td><td>".$name."</td> <td>"  .$row['MContent'].  "</td><td>"  .$row['MDate'].  "</td><input type='text' name='id1' value='".$row['DID']."'hidden>
<input type='text'  name='name1'  value='$name' hidden>
<input type='text'  name='type'  value='Driver' hidden>

";

echo "<td><button class='btn btn-gradient-primary mr-2'  name='msg' >Message</button>
</td></tr>";}

if($row['PID']!=NULL){
$id=$row['PID'];$sql1="SELECT * FROM Parent WHERE PID=$id";$s2 = mysqli_query($db, $sql1);$row2 = mysqli_fetch_array($s2);$name=$row2['PFName']." ".$row2['PLName'];
echo  "<td>".$row['PID']."</td><td>Parent</td><td>".$name."</td> <td>"  .$row['MContent'].  "</td><td>"  .$row['MDate'].  "</td><input type='text'id='id1'  name='id1'  value='".$row['PID']."'hidden> 
<input type='text'id='id1'  name='name1'  value='$name' hidden>
<input type='text'  name='type'  value='Parent' hidden>

";

echo "<td><button class='btn btn-gradient-primary mr-2'  name='msg' >Message</button>
</td></tr>";}
}}


}
                  echo"  </tbody>
                  </table>
                  </form>
              </div>
            </div>
              
            </div>
                     
          </div>

          
          
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <footer class='footer'>
          <div class='d-sm-flex justify-content-center justify-content-sm-between'>
            <span class='text-muted text-center text-sm-left d-block d-sm-inline-block'>Copyright © 2020 <a href='https://www.bootstrapdash.com/' target='_blank'>Bootstrap Dash</a>. All rights reserved.</span>
            <span class='float-none float-sm-right d-block mt-1 mt-sm-0 text-center'>Hand-crafted & made with <i class='mdi mdi-heart text-danger'></i></span>
          </div>
        </footer>
			  </div>

        <!-- partial -->
      </div>
	  </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  </div>
  <!-- container-scroller -->

  <!-- plugins:js -->
  <script src='AdminPagesStyle/vendors/js/vendor.bundle.base.js'></script>
  <script src='AdminPagesStyle/vendors/js/vendor.bundle.addons.js'></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src='AdminPagesStyle/js/off-canvas.js'></script>
  <script src='AdminPagesStyle/js/misc.js'></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src='AdminPagesStyle/js/dashboard.js'></script>
  <!-- End custom js for this page-->
</body>

</html>";
?>