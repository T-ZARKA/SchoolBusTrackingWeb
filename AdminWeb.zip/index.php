<?php 
include('functions.php');
echo"
<!DOCTYPE html>
<html lang='en'>

<head>
  <!-- Required meta tags -->
  <meta charset='utf-8'>
  <meta name='viewport' content='width=device-width, initial-scale=1, shrink-to-fit=no'>
  <title>Login</title>
  <!-- plugins:css -->
  <link rel='stylesheet' href='AdminPagesStyle/vendors/iconfonts/mdi/css/materialdesignicons.min.css'>
  <link rel='stylesheet' href='AdminPagesStyle/vendors/css/vendor.bundle.base.css'>
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel='stylesheet' href='AdminPagesStyle/css/style.css'>
  <!-- endinject -->
  <link rel='shortcut icon' href='AdminPagesStyle/images/bus1.png' />
</head

<body>
  <div class='container-scroller'>
    <div class='container-fluid page-body-wrapper full-page-wrapper'>
      <div class='content-wrapper d-flex align-items-center auth'>
        <div class='row w-100'>
          <div class='col-lg-4 mx-auto'>
            <div class='auth-form-light text-left p-5'>
              <div class='brand-logo'>
                <img src='AdminPagesStyle/images/bus1.png'>
              </div>
              <h4>Hello! </h4>
              <h6 class='font-weight-light'>Sign in to continue.</h6>
              <form class='pt-3' method='post' action='index.php' name='form' >
                <div class='form-group'>
                  <input type='text' class='form-control form-control-lg' name='AID' placeholder='ID'>
                </div>
                <div class='form-group'>
                  <input type='password' class='form-control form-control-lg' name='APassword' placeholder='Password'>
                </div>
                <div class='mt-3'>
                  <button type='submit' class='btn btn-block btn-gradient-primary btn-lg font-weight-medium auth-form-btn' name='login_btn' onClick='return required()'>SIGN IN</button>
                </div>
                <div class='my-2 d-flex justify-content-between align-items-center'>
                  
                </div>
             
              </form>
                
            </div>
          </div>
        </div>
      </div>
      <!-- content-wrapper ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <!-- plugins:js -->
  <script src='AdminPagesStyle/vendors/js/vendor.bundle.base.js'></script>
  <script src='AdminPagesStyle/vendors/js/vendor.bundle.addons.js'></script>
  <!-- endinject -->
  <!-- inject:js -->
  <script src='AdminPagesStyle/js/off-canvas.js'></script>
  <script src='AdminPagesStyle/js/misc.js'></script>
  <!-- endinject -->
</body>
<script>
                                            function required() {
                                                    var cf = document.forms['form']['AID'].value;
                                                    var cl = document.forms['form']['APassword'].value;



                                                    if (cf == '' || cl == '' ) {
                                                        alert('Please fill All Feilds');
                                                        return false;
                                                        
                                                    } else {
                                                        return true;
                                                    }

                                                }</script>
</html>";
?>